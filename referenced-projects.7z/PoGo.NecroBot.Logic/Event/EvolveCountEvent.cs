﻿namespace PoGo.NecroBot.Logic.Event
{
    public class EvolveCountEvent : IEvent
    {
        public int Evolves;
    }
}
