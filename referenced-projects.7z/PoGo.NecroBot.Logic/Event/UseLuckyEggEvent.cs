﻿namespace PoGo.NecroBot.Logic.Event
{
    public class UseLuckyEggEvent : IEvent
    {
        public int Count;
    }
}