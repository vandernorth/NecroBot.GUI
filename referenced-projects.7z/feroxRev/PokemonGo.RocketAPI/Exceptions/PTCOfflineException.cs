﻿using System;

namespace PokemonGo.RocketAPI.Exceptions
{
    public class PtcOfflineException : Exception
    {
    }
}