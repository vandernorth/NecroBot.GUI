Setup for Necrobot:

1. Run the NecroBot application and setup your credentials (google/ptc)
2. Go to the config directory and open config.json in Notepad, Sublime, Brackets, etc.
3. Change the "DefaultLatitude" and "DefaultLongitude" to your starting location.
	Change other parameters in the json file as you wish.
		**Note: changing "MaxTravelDistanceInMeters" to a large number (>=5000) may cause problems**
4. Run the NecroBot app again and start botting PoGo!

See the Discord chat below for questions. Be nice.
https://discord.gg/VXKxNFr
